# KahaniFilm — आख़िरी चाय reference intake

- Images inventoried: **78**
- Unique SHA-256 hashes: **45**
- Exact duplicate uploads: **33**
- Includes original image bytes, SHA-256 manifest, and contact sheet.
- This is an intake pack, not proof that the Android APK has imported the assets or rendered the film.

## Required next steps
1. Visually tag each reference as character / expression / pose / prop / location / lighting / action.
2. Establish a character and prop continuity bible using the approved images.
3. Map each shot to required assets and reject missing or conflicting references.
4. Import the pack into the app's reference library through the supported asset-import path.
5. Render the actual story, export frames/video, and inspect identity, staging, continuity, timing, and audio sync.
