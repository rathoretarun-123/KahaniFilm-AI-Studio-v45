# KahaniFilm Reference Asset Import Bundle

This bundle carries the uploaded source assets for both acceptance films. It keeps the original still/video file bytes; only folder names are organized.

## Contents
- `assets/babu_ke_liye/stills/`: the 53? uploaded still files as provided, with original names retained (byte-identical duplicates are not removed).
- `assets/babu_ke_liye/reference_video/`: the designated 10-second Babu reference video.
- `assets/babu_ke_liye/reference_video_variants/`: the other uploaded Babu video variant.
- `assets/aakhiri_chai/reference_pack/`: the intake ZIP and contact sheet.
- `assets/aakhiri_chai/reference_video/`: designated Aakhiri Chai reference video.
- `assets/aakhiri_chai/reference_video_variants/`: all remaining supplied Aakhiri Chai MP4 variants.
- `asset_inventory.json`: per-file sizes and SHA-256 checksums.
- `import_reference_assets.ps1`: imports files into the repo and commits/pushes using the user's existing Git credential setup.

## Push the binary files
1. Extract this ZIP completely.
2. On the Windows PC with Git configured, open PowerShell in the extracted folder.
3. Run: `powershell -ExecutionPolicy Bypass -File .\import_reference_assets.ps1 -RepoPath "C:\path\to\KahaniFilm-AI-Studio-v45"`
4. The script checks the target repo, refuses to overwrite uncommitted work, copies the exact assets under `tools/testdata/`, creates a commit, and pushes to `kahanifilm-development`.

This script does not add reference media to the Android APK assets folder; they remain test/reference resources under `tools/testdata` until the production loader explicitly uses them.
